# SomniWatch — Android sleep-monitoring research prototype

**Tagline:** Better Sleep. Healthier You.  
**Package:** `com.somniwatch.app` · **Version:** 1.0.0 · **Minimum Android:** 8.0 (API 26)

## Project contents
- `app/src/main/java/com/somniwatch/app/MainActivity.kt` — native Android WebView host.
- `app/src/main/assets/index.html` — responsive interface and client-side logic.
- `app/src/main/res/drawable/somni_icon.png` — custom launcher icon.
- Gradle Kotlin DSL build files.

## Build / install
Open this folder in Android Studio (Hedgehog or newer), allow Gradle sync, install Android SDK Platform 35 and a compatible Android Gradle Plugin, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Debug APK output should be at `app/build/outputs/apk/debug/app-debug.apk`. Or run `gradle assembleDebug` where Gradle and Android SDK are configured. The current authoring environment did not contain an Android SDK or Gradle distribution, so it could not compile or verify an APK here; do not treat this source archive as an APK.

## Demo mode
Demo mode is on by default. Synthetic samples are generated locally at 10 Hz and the UI labels them `SIMULATED` / `DEMO`. Estimated respiratory rate is computed from upward mean crossings in a rolling sample window, not from a hardcoded displayed rate. Synthetic events may be generated to exercise review flows. These events and measurements are **not real sleep observations**. Switch demo mode off to stop the synthetic stream. The app never claims a hardware connection until the WebSocket is connected and valid packets arrive.

## ESP32 WebSocket contract
Configure a WebSocket endpoint in Settings, e.g. `ws://192.168.1.50:81/data` on a trusted local network. The ESP32 must run a WebSocket server reachable by the phone. Each text frame should be JSON with this shape:

```json
{
  "device_id": "PIL-001",
  "timestamp": 1793000000000,
  "sensor_data": { "breathing_signal": 0.256, "raw": [0.12, 0.18, 0.21] },
  "metadata": { "battery_percent": 82, "signal_quality": "good", "sensor": "pressure" }
}
```

`timestamp` is Unix epoch milliseconds. `sensor_data.breathing_signal` is the filtered or raw scalar sensor channel in consistent units. The current client validates `device_id`, timestamp, and finite bounded `breathing_signal`; optional `metadata.battery_percent` updates battery display. Adapt the firmware and parser together if the real sensor's schema differs. Avoid internet-exposed unauthenticated endpoints; use a trusted isolated LAN and `wss://` with appropriate certificates for deployment. Never put Wi-Fi passwords or API secrets in the app source. Store network credentials securely on the ESP32 or in a separately configured secure provisioning flow.

### Suggested ESP32 message cadence
10–25 Hz is a reasonable prototyping cadence for a pressure / vibration signal, but choose a sampling rate based on the sensor and analog front-end. Timestamp samples at acquisition time. Do not use phone arrival time as a substitute for source timestamps in research analysis.

## Signal processing and limitations
- Samples are streamed into a rolling buffer.
- Respiratory rate is estimated by counting upward crossings of the rolling-window mean and scaling crossings per window to breaths/minute.
- A rough signal-quality score is derived from signal variance. It is only a UI heuristic.
- The demo stream generates synthetic sinusoidal/noisy samples and occasional simulated candidate events to test the alert and review UI.
- The app's prototype event generator is not a validated detector. Hardware event detection, robust filtering, motion artifact rejection, missing-packet analysis, calibration, timestamp alignment, and validated event thresholds still require engineering and validation against a suitable reference.
- No oxygen saturation or heart rate is estimated. A pressure/vibration signal alone cannot establish either metric or diagnose sleep apnea.
- Do not use for clinical decisions. `Possible Breathing Event — Review Required` is a candidate pattern only, not a diagnosis.

## Local data and privacy
Saved sessions, registered devices, and events are stored in WebView `localStorage` on this phone. No cloud backend is configured. Export downloads a JSON file. Clear local data permanently deletes locally stored devices, sessions and events. WebSocket traffic is sent to the configured local endpoint. Sleep-related data can be sensitive; protect device access and exported files. Retention settings delete records older than the selected age when applied.

## Functional test checklist
- [ ] Build and install debug APK on Android 8+.
- [ ] Dashboard opens and displays DEMO MODE.
- [ ] All / Online / Offline / Flagged filters update the device grid.
- [ ] Device cards navigate to the detail page.
- [ ] Demo waveform animates and the last-packet time updates.
- [ ] Respiratory-rate estimate changes with generated samples and is labelled simulated.
- [ ] Save session, open Recordings, replay waveform, and delete with confirmation.
- [ ] Event History filters by device/type; open event and mark reviewed.
- [ ] Register a device and verify it starts offline unless demo is explicitly chosen.
- [ ] Turn demo mode off and confirm synthetic stream stops.
- [ ] Connect to a test WebSocket endpoint; send valid and invalid JSON and verify status/error handling.
- [ ] Export JSON and inspect that it contains stored data.
- [ ] Apply retention policy and clear local data with confirmation.
- [ ] Test small screens, large text, landscape, back navigation, and offline operation.

## Known prototype limitations
This is a functional demo/source prototype, not a finished clinical monitoring system. The browser-based UI runs inside a native Android WebView. Android APK compilation and runtime testing must be completed in Android Studio because the authoring environment used to generate these files had no Android SDK/Gradle installation. Event detection is intentionally labelled as simulated in demo mode and needs a real signal-processing validation pass before hardware use.
